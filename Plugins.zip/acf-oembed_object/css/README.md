# CSS directory

Use this directory to store CSS files.

This directory can be removed if not used.
